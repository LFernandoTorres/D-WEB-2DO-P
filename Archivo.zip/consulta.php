<?php 
//Seguridad para evitar el uso de comillas
//SANEO DE CAMPOS - SANITIZAR CAMPOS
global $mysqli;
$consulta = "SELECT * FROM USUARIOS WHERE ..."


?>